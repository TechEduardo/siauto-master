package model.dto;

public class VendedorDTO extends FuncionarioDTO {

}
