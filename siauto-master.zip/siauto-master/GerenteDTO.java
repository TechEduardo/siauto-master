package model.dto;

public class GerenteDTO extends FuncionarioDTO {

    


}
    


